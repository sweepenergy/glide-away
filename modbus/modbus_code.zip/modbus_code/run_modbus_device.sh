#### "decimal_location":"value to store"
docker run --rm -p 5020:5020 -v /[file_location_of_server_config]/server_config.json:/server_config.json oitc/modbus-server:latest -f /server_config.json
